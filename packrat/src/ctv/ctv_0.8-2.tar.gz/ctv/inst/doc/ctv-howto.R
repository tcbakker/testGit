### R code from vignette source 'ctv-howto.Rnw'

###################################################
### code chunk number 1: ctv-howto.Rnw:126-129
###################################################
library("ctv")
x <- read.ctv(system.file("ctv", "Econometrics.ctv", package = "ctv"))
x


